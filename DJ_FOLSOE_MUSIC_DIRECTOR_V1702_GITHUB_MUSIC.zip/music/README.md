# DJ FOLSOE MUSIC DIRECTOR V1702

Et selvstændigt additivt modul, som ikke ændrer V1701, Cloudflare Worker, CMS/Admin, hjemmeside eller overlay.

## Hvad der er bygget
- Universal CSV-import til TuneMyMusic, Soundiiz, Spotify og Serato-lignende eksportfiler.
- Automatisk deduplikering efter Spotify-ID eller artist/titel/version.
- Lokal masterdatabase i browserens LocalStorage.
- Offentlig søgeside med artist, titel, år, land, genre, BPM, key, energi, play count og Spotify-link.
- Showprofiler til Good Morning Twitch, Trance Tuesday, Eurodance, Fredagsbar, Retro Hits, Weekend og Pop Up Live.
- Ugentlig Music Director-generator med genre-, energi-, BPM-, artist- og gentagelsesregler.
- Eksport til Master CSV, Soundiiz CSV, TuneMyMusic CSV og website JSON.
- Valgfri Spotify Publisher med Authorization Code + PKCE.
- Spotify playlist-items tilføjes i batches på højst 100.

## Installation på GitHub
1. Upload hele indholdet til en mappe som `/music/` i dit eksisterende website-repository.
2. Åbn `https://folsoetv.dk/music/` for den offentlige side.
3. Åbn `https://folsoetv.dk/music/admin.html` for Music Director.
4. Importér dine TuneMyMusic- og Soundiiz-CSV-filer.
5. Eksportér `music-database.json`.
6. Erstat `/music/data/music-database.json` med den eksporterede fil og upload til GitHub.

## Import fra TuneMyMusic og Soundiiz
Systemet genkender flere kolonnenavne automatisk. Soundiiz anbefaler en headerlinje og komma eller semikolon som separator.
TuneMyMusic/Soundiiz bruges som transport- og matchværktøjer; de leverer metadata, ikke lydfiler.

## Automatisk ugentlig playlist
Admin genererer forslag lokalt. En plan:
- undgår tracks spillet inden for showets karantæneperiode,
- begrænser samme artist til højst 2 tracks,
- filtrerer genre, BPM og energi,
- sorterer fra opvarmning mod peak time,
- kan eksporteres direkte til TuneMyMusic eller Soundiiz.

## Direkte Spotify
`spotify.html` kan oprette playlisten direkte:
1. Opret Spotify Developer-app.
2. Tilføj redirect-URI til den præcise URL for `spotify.html`.
3. Indsæt Client ID.
4. Forbind Spotify.
5. Vælg en godkendt CSV med Spotify-ID eller Spotify-links.
6. Opret playlisten.

## Næste integration i DJ FOLSOE NETWORK
Dette er V1702 Foundation. Når modulet er testet, kan dataflytning fra LocalStorage til den eksisterende Cloudflare Worker bygges additivt som `/api/music/*`, uden at ændre de låste broadcast-funktioner.
